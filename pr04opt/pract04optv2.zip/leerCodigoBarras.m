function [resultado] = leerCodigoBarras(img)
% Produce una imagen de salida en la que se etiquetan 
% los dígitos detectados con números y 
% devuelve el código completo como un entero.
    
    % carga las plantillas de los dígitos
    load('plantillas.mat');

    % umbrales para correlaciones
    umbrales = [0.9 0.8 0.8 0.8 0.8 0.85 0.8 0.8 0.8 0.70];

    % busca las correlaciones con los dígitos
    correls = zeros(size(img));
    for np = 1:10 % para cada dígito del 1 al 0
        imc = normxcorr2(plantillas(np).im, img);
        [x, y] = find(imc > umbrales(np));
        correls(x, y) = np;
    end

    % busca las regiones conectadas
    etiquetas = bwlabel(imbinarize(correls));
    numdigitos = max(max(etiquetas));
   
    % prepara el resultado y la imagen a visualizar
    resultado = "";
    figure
    imshow(img); 
    hold on;

    % para cada etiqueta, visualiza el valor y lo asigna
    for i=1:numdigitos
        [x, y] = find(etiquetas == i);
        cx = min(x);
        cy = min(y);
        val = correls(cx, cy);
        if (val == 10)
            val = 0;
        end
        text (cy-15, cx+10, int2str(val), 'Color','r');
        resultado = strcat(resultado, int2str(val));
    end

    % convierte el resultado a entero
    resultado = str2num(resultado);
end